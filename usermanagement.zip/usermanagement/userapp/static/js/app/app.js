var app = angular.module("userApp", ['ngRoute']);

app.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
            when('/usersave', {
                templateUrl: static_url + 'html/usersave.html',
                controller: 'UserSaveController'
            }).
            when('/showuserdetails', {
                templateUrl: static_url + 'html/userdetailshow.html',
                controller: 'ShowDetailController'
            }).
            otherwise({
                redirectTo: '/usersave'
            });
    }]);

//
//app.controller("UserSaveController ", function($scope) {
//
//		console.info("UserSaveController");
//		$scope.items = [];
//
//		$scope.saveUser = function (user) {
//		    console.info("UserSaveController",user);
//
//			$scope.items = [];
//
//			angular.forEach(user, function (value, key) {
//				// console.log(key + ': ' + value);
//					$scope.items.push(value);
//
//
//
//			});
//
//			console.info($scope.items);
//
//
//			$http({
//				url: "http://localhost:8080/usersave/",
//				method: 'POST',
//				data: $scope.items
//			})
//				.success(function (res) {
//					console.log("Saved User success:::: ", res);
//
//				})
//				.error(function (res) {
//					console.log("user failed::::", res);
//				})
//
//		};
//
//
//		$scope.addAddress = function (address) {
//		add = address.Address
//		console.info("addAddress::::::::",add);
//			$scope.addresslist = [];
//                        $scope.addresslist.push(add);
//                        $scope.user.Address = Null
//			console.info($scope.items);
//		};
//
//               $scope.addTechSkill= function (techskill) {
//               techskill = address.TechnicalSkills
//			$scope.techskilllist = [];
//                        $scope.techskilllist.push(techskill);
//                        $scope.user.TechnicalSkills = Null
//			console.info($scope.items);
//		};
//});

app.controller("UserSaveController", function($scope,$http) {
    console.info("UserSaveController");
		console.info("UserSaveController");
		$scope.items = [];
		$scope.user ={};
		$scope.addresslist = [];
		$scope.techskilllist = [];
		 $scope.myValue = true

		$scope.saveUser = function (user) {
		    console.info("UserSaveController",user);

			$scope.items = [];
			var val = {
	"username" : user.UserName,
	"age" : user.Age,
	"gender" :user.Gender,
	"address" : $scope.addresslist,
	"techskill" : $scope.techskilllist
}
			$http({
				url: "http://localhost:8080/saveuser/",
				method: 'POST',
				data: val
			})
				.success(function (res) {
					console.log("Saved User success:::: ", res);
					if(res == 'success'){
                        myValue = false
					}

				})
				.error(function (res) {
					console.log("user failed::::", res);
				})

		};


		$scope.addAddress = function (address) {
		add = address.Address
		console.info("addAddress::::::::",address);


                        $scope.addresslist.push(add);
                        $scope.user.Address = ''
			console.info($scope.addresslist);
		};

               $scope.addTechSkill= function (techskill) {
               techskill = address.TechnicalSkills

                        $scope.techskilllist.push(techskill);
                        $scope.user.TechnicalSkills = ''
			console.info($scope.techskilllist);
		};
});




app.controller("ShowDetailController", function($scope,$http) {
    console.info("ShowDetailController");
		$scope.items = [];

			$http({
				url: "http://localhost:8080/getuserdetails/",
				method: 'GET'
			})
				.success(function (res) {

                    $scope. userdetails = res;

					console.log("Get User Details success:::: ", res);

				})
				.error(function (res) {
					console.log("user failed::::", res);
				})


});

