from django.contrib import admin
from userapp.models import UserDetail
from userapp.models import Address
from userapp.models import Techskill
admin.site.register(UserDetail)
admin.site.register(Address)
admin.site.register(Techskill)
# Register your models here.
