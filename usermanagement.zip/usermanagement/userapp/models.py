from django.db import models

class Address(models.Model):
    address=models.TextField(null=True)

    def __str__(self):
        return "%s %s" % (self.address)

class Techskill(models.Model):
    technical_skill= models.CharField(max_length=300)

    def __str__(self):
        return "%s %s" % (self.technical_skill)


class UserDetail(models.Model):
    name= models.CharField(max_length=100)
    age = models.CharField(max_length=100)
    gender = models.CharField(max_length=100)
    # addresses = models.ForeignKey(Address, on_delete=models.CASCADE, null=True)
    # tech_skill = models.ForeignKey(Techskill,related_name='techskill' , on_delete=models.CASCADE, null=True)
    addresses = models.ForeignKey(Address, on_delete=models.PROTECT, null=True, related_name='addresses')
    tech_skill = models.ForeignKey(Techskill, on_delete=models.PROTECT, null=True, related_name='tech_skill')
    # addresses = models.ForeignKey(Address, null=True, related_name='addresses')
    # tech_skill = models.ForeignKey(Techskill, null=True, on_delete=models.CASCADE)
    def __str__(self):
        return self.name

    class Meta:
        ordering = ('name',)