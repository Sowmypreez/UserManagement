from django.views.decorators.csrf import csrf_exempt
from rest_framework.views import APIView
from rest_framework.decorators import api_view
import json
from userapp.models import Address
from userapp.models import Techskill
from userapp.models import UserDetail
from django.core import serializers
from django.http import JsonResponse
from rest_framework.response import Response
from usermanagement import settings
from django.shortcuts import render

def home(req):
    return render(req, 'index.html', {'STATIC_URL': settings.STATIC_URL})

class usersaving(APIView):

    @csrf_exempt
    @api_view(['GET', 'POST', ])
    def usersave(request):
        print("usersaving SAVE BODY REQUEST", request.body)
        data = json.loads(request.body)
        print("SAVE BODY data", data)
        name = data["username"]
        age = data["age"]
        gender = data["gender"]
        address = data["address"]
        techskill = data["techskill"]
        print("name", name)
        print("age", age)
        print("gender", gender)
        print("address", address)
        print("natechskillme", techskill)
        addModel = Address()
        techModel = Techskill()

        addModel.address = json.dumps(address)
        addModel.save()

        techModel.technical_skill = json.dumps(techskill)
        techModel.save()

        user = UserDetail(name=name, age=age, gender=gender, addresses=addModel, tech_skill=techModel)
        user.save()

        return Response("success")


class gettinguser(APIView):

    @csrf_exempt
    @api_view(['GET', 'POST', ])
    def getuser(request):
        SomeModel_json = serializers.serialize("json", UserDetail.objects.all())
        data = {"SomeModel_json": SomeModel_json}
        print("data1",data)
        return JsonResponse(data)
